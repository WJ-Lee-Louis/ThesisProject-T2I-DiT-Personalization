import hashlib
import io
import json
from pathlib import Path
import tempfile
import unittest
import zipfile

import torch

from xlabs_application.config import ACCOUNTS, SETTINGS
from xlabs_application.inference import edit_embedding, validate_cache
from xlabs_application.io import extract
from xlabs_application.runtime import signature
from xlabs_application.vendor.contrast_directions import build_contrast_directions
from xlabs_application.vendor.semantic_contrasts import SemanticContrastConditioning

ORIGINAL = Path(__file__).resolve().parents[2] / 'Orthogonalization-InstantX-IP-Adapter'
CACHE = ORIGINAL / 'outputs/semantic_benchmark_gpt56_sol/conditioning'


def encode(texts):
    return torch.tensor([list(hashlib.sha256(t.encode()).digest()) for t in texts], dtype=torch.float32) - 127


class ContractTests(unittest.TestCase):
    def test_projected_geometry_and_norm(self):
        c = SemanticContrastConditioning.from_dict(json.loads((CACHE / '000-00.json').read_text(encoding='utf-8')))
        visual = torch.randn(1, 32)
        edited, diag = edit_embedding(visual, c, encode)
        self.assertGreater(diag['basis_rank'], 0)
        self.assertLess(diag['projection']['max_abs_basis_dot'][0], 1e-5)
        torch.testing.assert_close(edited.norm(), visual.norm())

    def test_strength_zero_is_exact_noop(self):
        c = SemanticContrastConditioning.from_dict(json.loads((CACHE / '000-00.json').read_text(encoding='utf-8')))
        v = torch.randn(1, 32)
        out, _ = edit_embedding(v, c, encode, strength=0)
        self.assertTrue(torch.equal(out, v))

    def test_fallback_empty_is_exact_noop(self):
        c = SemanticContrastConditioning.from_dict(json.loads((CACHE / '092-08.json').read_text(encoding='utf-8')))
        v = torch.randn(1, 32)
        out, diag = edit_embedding(v, c, encode)
        self.assertEqual(diag['basis_rank'], 0)
        self.assertTrue(diag['target_projection_skipped'])
        self.assertTrue(torch.equal(out, v))

    def test_second_fallback_retains_source_only(self):
        c = SemanticContrastConditioning.from_dict(json.loads((CACHE / '154-07.json').read_text(encoding='utf-8')))
        d = build_contrast_directions(c, encode)
        self.assertEqual(len(d.values), 1)
        self.assertTrue(d.names[0].startswith('source:'))

    def test_negative_sign_and_input_order(self):
        c = SemanticContrastConditioning.from_dict(json.loads((CACHE / '000-00.json').read_text(encoding='utf-8')))
        rows = build_contrast_directions(c, encode)
        p = c.analysis.source_caption
        n = c.analysis.source[0].negative
        ep, en = torch.nn.functional.normalize(encode([p, n]), dim=-1)
        expected = torch.nn.functional.normalize(ep - en, dim=0)
        torch.testing.assert_close(rows.values[0], expected)

    def test_condition_and_input_bound_signature(self):
        p = dict(code='x', models={}, settings=SETTINGS)
        row = dict(case_id='a', target_prompt='dog')
        self.assertNotEqual(signature(p, row, 'baseline'), signature(p, row, 'source_target'))
        self.assertNotEqual(signature(p, row, 'baseline'), signature(p, dict(row, target_prompt='cat'), 'baseline'))

    def test_zip_traversal_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            archive = Path(tmp) / 'bad.zip'
            with zipfile.ZipFile(archive, 'w') as z:
                z.writestr('../escape', 'x')
            with self.assertRaises(ValueError):
                extract(archive, Path(tmp) / 'out')


if __name__ == '__main__':
    unittest.main()
