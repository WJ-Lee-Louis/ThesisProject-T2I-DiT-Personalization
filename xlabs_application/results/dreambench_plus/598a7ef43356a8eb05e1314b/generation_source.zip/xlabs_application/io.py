"""Portable hashes, atomic publication and safe archive extraction."""
import hashlib
import json
from pathlib import Path
import zipfile


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def sha(path):
    result = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024**2), b""):
            result.update(block)
    return result.hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temp.replace(path)


def extract(archive, destination):
    destination = Path(destination).resolve()
    with zipfile.ZipFile(archive) as z:
        for info in z.infolist():
            name = info.filename
            if ("\\" in name or ":" in name or name.startswith("/")
                    or ".." in Path(name).parts or (info.external_attr >> 16) & 0o170000 == 0o120000
                    or not (destination / name).resolve().is_relative_to(destination)):
                raise ValueError("Unsafe ZIP member")
        z.extractall(destination)
